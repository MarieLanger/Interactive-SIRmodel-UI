"""
Last edited on Jun 6 2021

Authors:
- SIR()-method: Tom Richard Vargis
- SIR_PH_Gamma()-method: Moritz Schramm
- SIR_PH_Matrix()-method: Tom Richard Vargis
- The rest: Marie Langer

DESCRIPTION:
- For 1 model, this class keeps track of the selected values for each of the variables.
- If new variable values were selected, it automatically calculates the new values for the
  np-arrays S/I/R. (Done in the updateSIRvalues()-method)
- The different SIR-functions (Normal SIR(), and the two population-heterogenity-models (SIR_PH_Gamma(),SIR_PH_Matrix())
  are used accordingly in the updateSIRvalues()-method
- In the UI, up to 4 models can be plotted simultaneously, hence, ModelInstance() is called 4 times by
  the Models()-class
"""

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt


class ModelInstance:
    # 4 instances of models
    def __init__(self):
        self.showPlot_INDEX = False
        self.beta_INDEX = 10
        self.gamma_INDEX = 7
        self.lockdown_INDEX = False
        self.lockdownStart_INDEX = 0
        self.lockdownDuration_INDEX = 0
        self.lockdownIntensity_INDEX = 0
        self.popHetType_INDEX = 0
        self.popHetVar_INDEX = 0

        # When manipulating variables, access this list
        self.variables = [self.showPlot_INDEX, self.beta_INDEX, self.gamma_INDEX, self.lockdown_INDEX,
                          self.lockdownStart_INDEX, self.lockdownDuration_INDEX,
                          self.lockdownIntensity_INDEX, self.popHetType_INDEX,
                          self.popHetVar_INDEX]

        # Every modelInstance-instance has a specific sequence of S/I/R that will be potted
        self.S = None
        self.I = None
        self.R = None

        # Ranges
        self.betaRange = np.round(np.linspace(0, 1, 21), 2)
        self.gammaRange = np.round(np.linspace(0, 1, 21), 2)
        self.lockdownStartRange = np.round(np.linspace(10, 60, 21), 0)
        self.lockdownDurationRange = np.round(np.linspace(10, 60, 21), 0)
        self.lockdownIntensityRange = np.round(np.linspace(0, 1, 21), 2)
        self.popHetTypeRange = ["Homogen", "Gamma", "Matrix"]
        self.popHetVarRange = np.round(np.linspace(0.05, 1.05, 21), 2)  # We get error if we selected 0
        self.variableRanges = [0, self.betaRange, self.gammaRange, 0, self.lockdownStartRange,
                               self.lockdownDurationRange,
                               self.lockdownIntensityRange, self.popHetTypeRange,
                               self.popHetVarRange]  # insert 0 so that indexing is as before

    # When other variable-values were chosen
    def updateSIRvalues(self):
        # Define variables in function for better readability
        lockdown = self.variables[3]
        lockdownStart = self.variableRanges[4][self.variables[4]]
        lockdownDuration = self.variableRanges[5][self.variables[5]]
        lockdownIntensity = self.variableRanges[6][self.variables[6]]
        popHetType = self.variableRanges[7][self.variables[7]]
        popHetVar = self.variableRanges[8][self.variables[8]]

        # We differentiate between 4 cases:
        #      Lockdown: Yes/No
        #      Population Heterogenity: Yes/No?
        #             If yes: Which type?

        # If we're in lockdown (See: Apendix of report)
        if lockdown:
            if popHetType == "Homogen":
                tmp1 = self.SIR(999, 1, 0, lockdownStart, self.variableRanges[1][int(self.variables[1])],
                                self.variableRanges[2][self.variables[2]])
                self.S, self.I, self.R = tmp1

                tmp2 = self.SIR(tmp1[0][-1], tmp1[1][-1], tmp1[2][-1], lockdownDuration,
                                self.variableRanges[1][self.variables[1]] * lockdownIntensity,
                                self.variableRanges[2][self.variables[2]])
                self.S = np.concatenate((self.S, tmp2[0][1:-1]))
                self.I = np.concatenate((self.I, tmp2[1][1:-1]))
                self.R = np.concatenate((self.R, tmp2[2][1:-1]))

                tmp3 = self.SIR(tmp2[0][-1], tmp2[1][-1], tmp2[2][-1], 200 - lockdownStart - lockdownDuration + 2 + 2,
                                self.variableRanges[1][self.variables[1]],
                                self.variableRanges[2][self.variables[2]])
                self.S = np.concatenate((self.S, tmp3[0][1:-1]))
                self.I = np.concatenate((self.I, tmp3[1][1:-1]))
                self.R = np.concatenate((self.R, tmp3[2][1:-1]))


            elif popHetType == "Gamma":
                tmp1 = self.SIR_PH_Gamma(999, 1, 0, lockdownStart, self.variableRanges[1][int(self.variables[1])],
                                         self.variableRanges[2][self.variables[2]], popHetVar)
                self.S, self.I, self.R = tmp1

                tmp2 = self.SIR_PH_Gamma(tmp1[0][-1], tmp1[1][-1], tmp1[2][-1], lockdownDuration,
                                         self.variableRanges[1][self.variables[1]] * lockdownIntensity,
                                         self.variableRanges[2][self.variables[2]], popHetVar)
                self.S = np.concatenate((self.S, tmp2[0][1:-1]))
                self.I = np.concatenate((self.I, tmp2[1][1:-1]))
                self.R = np.concatenate((self.R, tmp2[2][1:-1]))

                tmp3 = self.SIR_PH_Gamma(tmp2[0][-1], tmp2[1][-1], tmp2[2][-1],
                                         200 - lockdownStart - lockdownDuration + 2 + 2,
                                         self.variableRanges[1][self.variables[1]],
                                         self.variableRanges[2][self.variables[2]], popHetVar)
                self.S = np.concatenate((self.S, tmp3[0][1:-1]))
                self.I = np.concatenate((self.I, tmp3[1][1:-1]))
                self.R = np.concatenate((self.R, tmp3[2][1:-1]))


            elif popHetType == "Matrix":
                # Calculate initial conditions
                beta = np.array([[2.2257, 0.4136, 0.2342, 0.4539, 0.2085, 0.1506],
                                 [0.4139, 3.6140, 0.4251, 0.4587, 0.2712, 0.1514],
                                 [0.2342, 0.4257, 2.9514, 0.6682, 0.4936, 0.1972],
                                 [0.4539, 0.4592, 0.6676, 0.9958, 0.6510, 0.3300],
                                 [0.2088, 0.2706, 0.4942, 0.6508, 0.8066, 0.4341],
                                 [0.1507, 0.1520, 0.1968, 0.3303, 0.4344, 0.7136]])
                poprat = np.array([0.0725, 0.0866, 0.1124, 0.3323, 0.2267, 0.1695])
                i0 = np.zeros(6)
                r0 = np.zeros(6)
                e0 = np.zeros(6)
                e0[0] = 1 / (1000 * poprat[0])
                s0 = poprat - i0 - r0 - e0
                y0 = np.concatenate((s0, e0, i0, r0))


                # Calculating 3 SEIR models
                # Before lockdown
                retT = self.SIR_PH_Matrix(y0, lockdownStart, popHetVar, beta, self.variableRanges[2][self.variables[2]])
                self.S = np.sum(retT[0:6], axis=0) * 1000  # *1000 necessary because this model works with percentages
                self.I = np.sum(retT[12:18], axis=0) * 1000  # S,I,R here are absolute numbers
                self.R = np.sum(retT[18:24], axis=0) * 1000

                # During lockdown
                retT = np.asmatrix(retT.T)
                y0 = np.zeros(24)
                for i in range(23):
                    y0[i] = retT[-1].tolist()[:][0][i]
                retT = self.SIR_PH_Matrix(y0, lockdownDuration, popHetVar, beta * lockdownIntensity,
                                          self.variableRanges[2][self.variables[2]])
                self.S = np.concatenate((self.S, np.sum(retT[0:6], axis=0) * 1000))
                self.I = np.concatenate((self.I, np.sum(retT[12:18], axis=0) * 1000))
                self.R = np.concatenate((self.R, np.sum(retT[18:24], axis=0) * 1000))

                # After lockdown
                retT = np.asmatrix(retT.T)
                y0 = np.zeros(24)
                for i in range(23):
                    y0[i] = retT[-1].tolist()[:][0][i]
                retT = self.SIR_PH_Matrix(y0, 200 - lockdownStart - lockdownDuration, popHetVar, beta,
                                          self.variableRanges[2][self.variables[2]])
                self.S = np.concatenate((self.S, np.sum(retT[0:6], axis=0) * 1000))
                self.I = np.concatenate((self.I, np.sum(retT[12:18], axis=0) * 1000))
                self.R = np.concatenate((self.R, np.sum(retT[18:24], axis=0) * 1000))

            else:
                print("Error: No valid type of population heterogenity selected!")


        # If there is no lockdown
        else:
            if popHetType == "Homogen":
                self.S, self.I, self.R = self.SIR(999, 1, 0, 200, self.variableRanges[1][self.variables[1]],
                                                  self.variableRanges[2][self.variables[2]])
            elif popHetType == "Gamma":
                self.S, self.I, self.R = self.SIR_PH_Gamma(999, 1, 0, 200, self.variableRanges[1][self.variables[1]],
                                                           self.variableRanges[2][self.variables[2]], popHetVar)
            elif popHetType == "Matrix":
                # Calculate initial conditions
                beta = np.array([[2.2257, 0.4136, 0.2342, 0.4539, 0.2085, 0.1506],
                                 [0.4139, 3.6140, 0.4251, 0.4587, 0.2712, 0.1514],
                                 [0.2342, 0.4257, 2.9514, 0.6682, 0.4936, 0.1972],
                                 [0.4539, 0.4592, 0.6676, 0.9958, 0.6510, 0.3300],
                                 [0.2088, 0.2706, 0.4942, 0.6508, 0.8066, 0.4341],
                                 [0.1507, 0.1520, 0.1968, 0.3303, 0.4344, 0.7136]])
                poprat = np.array([0.0725, 0.0866, 0.1124, 0.3323, 0.2267, 0.1695])

                i0 = np.zeros(6)
                r0 = np.zeros(6)
                e0 = np.zeros(6)
                e0[0] = 1 / (1000 * poprat[0])
                s0 = poprat - i0 - r0 - e0
                y0 = np.concatenate((s0, e0, i0, r0))
                retT = self.SIR_PH_Matrix(y0, 200, popHetVar, beta, self.variableRanges[2][self.variables[2]])

                self.S = np.sum(retT[0:6], axis=0) * 1000
                self.I = np.sum(retT[12:18], axis=0) * 1000
                self.R = np.sum(retT[18:24], axis=0) * 1000


            else:
                print("Error: No valid type of population heterogenity selected!")

    def SIR(self, S0, I0, R0, timeDuration, beta1, gamma1):
        """
        Created on Sat May 15

        @author: Tom Richard Vargis
        """

        # Define actual model function so that it can be used later
        def modelFunction(y2, t2, N2, beta2, gamma2):
            S2, I2, R2 = y2
            dSdt = -beta2 * S2 * I2 / N2
            dIdt = beta2 * S2 * I2 / N2 - gamma2 * I2
            dRdt = gamma2 * I2
            return dSdt, dIdt, dRdt

        # Initialize variabled needed
        N = S0 + I0 + R0
        N = int(N)
        y0 = int(S0), int(I0), int(R0)
        S = None
        I = None
        R = None
        y = None
        t = np.linspace(0, int(timeDuration), int(timeDuration))

        ret = odeint(modelFunction, y0, t, args=(N, beta1, gamma1))
        S, I, R = ret.T
        return S, I, R

    def SIR_PH_Gamma(self, S0, I0, R0, timeDuration, beta1, gamma1, alpha1):
        # !/usr/bin/env python3
        # -*- coding: utf-8 -*-
        """
        Created on Fri Jun  4 09:01:23 2021

        @author: Moritz Schramm
        """

        # Define actual model function so that it can be used later
        def modelFunction(y2, t2, N2, beta2, gamma2, alpha2, I02):
            S2, I2, R2, tau2 = y2
            dTaudt = beta2 * I2 / N2
            dSdt = -(I2 * beta2 * (1 - I02 / N2) * (1 + tau2 / alpha2) ** (-alpha2 - 1))
            dIdt = I2 * beta2 * (1 - I02 / N2) * (1 + tau2 / alpha2) ** (-alpha2 - 1) - gamma2 * I2
            dRdt = gamma2 * I2
            return dSdt, dIdt, dRdt, dTaudt

        # Initialize variables needed
        N = S0 + I0 + R0
        N = int(N)
        y0 = int(S0), int(I0), int(R0), 0.0
        S = None
        I = None
        R = None
        tau = None
        y = None
        t = np.linspace(0, int(timeDuration), int(timeDuration))

        ret = odeint(modelFunction, y0, t, args=(N, beta1, gamma1, alpha1, I0))
        S, I, R, tau = ret.T
        # additional characteristic values to analyze course of epidemic, optional
        xbar = 1 / (1 + tau / alpha1)  # average susceptibility
        norm_rep = xbar ** (1 + alpha1)  # normalized time dependent reproduction number
        J = beta1 * xbar * I * S / N  # rate of new cases per day
        C = N - S  # cumulative cases
        return S, I, R  # optionally return also: tau, xbar, norm_rep, J

    def SIR_PH_Matrix(self, y0, timeDuration, alpha, beta, gamma):
        # Model
        def modelFunction(y, t, alpha, beta, gamma):
            poprat = np.array([0.0725, 0.0866, 0.1124, 0.3323, 0.2267, 0.1695])
            s1, s2, s3, s4, s5, s6, e1, e2, e3, e4, e5, e6, i1, i2, i3, i4, i5, i6, r1, r2, r3, r4, r5, r6 = y
            dsdt = [s1, s2, s3, s4, s5, s6] * np.sum(poprat * beta * [i1, i2, i3, i4, i5, i6], axis=1) * -1 * ctrl
            dedt = [s1, s2, s3, s4, s5, s6] * np.sum(poprat * beta * [i1, i2, i3, i4, i5, i6],
                                                     axis=1) * ctrl - alpha * np.array([e1, e2, e3, e4, e5, e6])
            didt = alpha * np.array([e1, e2, e3, e4, e5, e6]) - gamma * np.array([i1, i2, i3, i4, i5, i6])
            drdt = gamma * np.array([i1, i2, i3, i4, i5, i6])
            derivatives = np.concatenate((dsdt, dedt, didt, drdt))
            return derivatives

        # declare variables
        t = np.linspace(0, int(timeDuration), int(timeDuration))
        ctrl = 1

        # Integrate the SIR equations over the time grid, t.
        ret = odeint(modelFunction, y0, t, args=(alpha, beta, gamma))
        return ret.T
