"""
Last edited on Jun 6 2021

Author: Marie

DESCRIPTION:
- The class Models() calls the ModelInstance()-class 4 times in order to create the 4 models,
  for which the user can specify parameters.
- This class therefore provides an overview of all variables
- It further keeps track of which model is currently selected + which variable is selected currently
  ("Where exactly is the blue rectangle?")
- Models() is called by the Main()-function of the class MainRun().
"""

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import os
import json


class Models:
    def __init__(self):
        from classes.ModelInstance import ModelInstance
        self.modelList = [ModelInstance(), ModelInstance(), ModelInstance(), ModelInstance()]  # 4 instances get created
        self.currentModel = 0  # current selected model
        self.currentVariable = 0  # current selected variable

        self.variableNum = len(self.modelList[0].variables)  # number of variables, for easier access if method needs it

        self.modelEdit = False  # do I navigate through the variables (=false) or do I edit variables (=true)?

        # Define variable ranges
        self.betaRange = np.round(np.linspace(0, 1, 21), 2)
        self.gammaRange = np.round(np.linspace(0, 1, 21), 2)
        self.lockdownStartRange = np.round(np.linspace(10, 60, 21), 0)
        self.lockdownDurationRange = np.round(np.linspace(10, 60, 21), 0)
        self.lockdownIntensityRange = np.round(np.linspace(0, 1, 21), 2)
        self.popHetTypeRange = ["Homogen", "Gamma", "Matrix"]
        self.popHetVarRange = np.round(np.linspace(0.05, 1.05, 21), 2)  # We get error if we select 0
        self.variableRanges = [0, self.betaRange, self.gammaRange, 0, self.lockdownStartRange,
                               self.lockdownDurationRange,
                               self.lockdownIntensityRange, self.popHetTypeRange,
                               self.popHetVarRange]  # insert 0 so that indexing is as before

        self.variableDescription = ["Show plot?", "beta", "gamma", "Lockdown?", "L_start", "L_duration", "L_redRate",
                                    "P_Type?", "P_H_var"]

        # Loading default values
        self.defaultValues = {}
        self.defaultIDs = ["test", "test2", "test3", "covid", "ebola", "measles", "polio"]

    def loadPresetValues(self):
        # Open json-file with preset-values
        """data_folder = os.path.join(os.path.dirname(__file__), "../data/defaultValues.json")  # ../
        with open(data_folder, "r") as f:
            jsonData = json.load(f)
            print(jsonData)"""
        jsonData = {
            'test': {'Show plot?': True, 'beta': 0.6, 'gamma': 0.3, 'Lockdown?': False, 'L_start': 10, 'L_duration': 48,
                     'L_redRate': 0.5, 'P_Type?': 'Homogen', 'P_H_var': 0.05},
            'test2': {'Show plot?': True, 'beta': 0.5, 'gamma': 0.25, 'Lockdown?': True, 'L_start': 15,
                      'L_duration': 60, 'L_redRate': 0.5, 'P_Type?': 'Homogen', 'P_H_var': 0.05},
            'test3': {'Show plot?': True, 'beta': 0.5, 'gamma': 0.25, 'Lockdown?': True, 'L_start': 15,
                      'L_duration': 35, 'L_redRate': 0.45, 'P_Type?': 'Homogen', 'P_H_var': 0.05},
            'covid': {'Show plot?': True, 'beta': 0.6, 'gamma': 0.2, 'Lockdown?': False, 'L_start': 10,
                      'L_duration': 60, 'L_redRate': 0.45, 'P_Type?': 'Homogen', 'P_H_var': 0.05},
            'ebola': {'Show plot?': True, 'beta': 0.2, 'gamma': 0.1, 'Lockdown?': False, 'L_start': 10,
                      'L_duration': 48, 'L_redRate': 0.5, 'P_Type?': 'Homogen', 'P_H_var': 0.05},
            'measles': {'Show plot?': True, 'beta': 1.0, 'gamma': 0.2, 'Lockdown?': False, 'L_start': 10,
                        'L_duration': 48, 'L_redRate': 0.5, 'P_Type?': 'Homogen', 'P_H_var': 0.05},
            'polio': {'Show plot?': True, 'beta': 0.3, 'gamma': 0.05, 'Lockdown?': False, 'L_start': 10,
                      'L_duration': 48, 'L_redRate': 0.5, 'P_Type?': 'Homogen', 'P_H_var': 0.05}}

        # Do the same for all preset-IDs:
        for id in range(len(self.defaultIDs)):
            variableList = []
            indexList = []

            # From specific ID: Extract all variables in their respective order
            for v in self.variableDescription:
                variableList.append(jsonData[self.defaultIDs[id]][v])

            # For all variables: Check which index they have
            for v in range(len(self.variableDescription)):
                if type(variableList[v]) == bool:
                    indexList.append(variableList[v])
                else:
                    indexList.append(list(self.variableRanges[v]).index(variableList[v]))

            # Append indexList to dict {"test":[0,4,2,12,0]}
            self.defaultValues[self.defaultIDs[id]] = indexList

    def setPreset(self, id):
        # do for all variables
        for v in range(len(self.variableRanges)):
            self.modelList[self.currentModel].variables[v] = self.defaultValues[id][v]


Models().loadPresetValues()
