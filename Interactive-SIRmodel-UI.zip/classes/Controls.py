"""
Last edited on Jun 6 2021

Author: Marie Langer


DESCRIPTION:
This class is used to handle user inputs and stores which keys were pressed/released recently.
It uses the Pygame-library.
"""

import pygame

class Controls:
    def __init__(self):
        self.running = True
        self.keyPressedLeft = False
        self.keyPressedRight = False
        self.keyPressedUp = False
        self.keyPressedDown = False
        self.keyPressedY = False
        self.keyPressedX = False
        self.keyPressedQ = False
        self.keyPressedW = False
        self.keyPressedC = False
        self.keyPressedE = False
        self.keyPressedM = False
        self.keyPressedP = False
        self.keyPressedR = False

    def evaluatePressedKeys(self):
        # Get all keyboard events
        events = pygame.event.get()
        for event in events:

            if event.type == pygame.QUIT:  # When close button is pressed
                self.running = False

            # If key was pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.keyPressedLeft = True
                if event.key == pygame.K_RIGHT:
                    self.keyPressedRight = True
                if event.key == pygame.K_UP:
                    self.keyPressedUp = True
                if event.key == pygame.K_DOWN:
                    self.keyPressedDown = True
                if event.key == pygame.K_y:
                    self.keyPressedY = True
                if event.key == pygame.K_x:
                    self.keyPressedX = True
                if event.key == pygame.K_q:
                    self.keyPressedQ = True
                if event.key == pygame.K_e:
                    self.keyPressedE = True
                if event.key == pygame.K_c:
                    self.keyPressedC = True
                if event.key == pygame.K_m:
                    self.keyPressedM = True
                if event.key == pygame.K_p:
                    self.keyPressedP = True
                if event.key == pygame.K_r:
                    self.keyPressedR = True

            # If key was released
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT:
                    self.keyPressedLeft = False
                if event.key == pygame.K_RIGHT:
                    self.keyPressedRight = False
                if event.key == pygame.K_UP:
                    self.keyPressedUp = False
                if event.key == pygame.K_DOWN:
                    self.keyPressedDown = False
                if event.key == pygame.K_y:
                    self.keyPressedY = False
                if event.key == pygame.K_x:
                    self.keyPressedX = False
                if event.key == pygame.K_q:
                    self.keyPressedQ = False
                if event.key == pygame.K_e:
                    self.keyPressedE = False
                if event.key == pygame.K_c:
                    self.keyPressedC = False
                if event.key == pygame.K_m:
                    self.keyPressedM = False
                if event.key == pygame.K_p:
                    self.keyPressedP = False
                if event.key == pygame.K_r:
                    self.keyPressedR = False
