"""
Last edited on Jun 23 2021

Author: Marie Langer

DESCRIPTION:
- The MainRun()-class is used to run the whole program, as well as to initialize/ create the Pygame-interface that
  allows the display of computer graphics
- The running of the program, as well as the visualization is done in a function called Main(),
  which is belongs to the MainRun()-class.
- The Main()-function runs automatically when an instance of the MainRun()-class gets created.
"""


class MainRun:
    def __init__(self):
        # Initialize classes that are used by Main-function
        self.controls = None
        self.models = None

        # Initialize variables that are needed later on
        self.font = None
        self.fontBig = None
        self.fontBIG = None

        fig2 = None
        ax1 = None
        ax2 = None
        self.figCounter = None
        self.plotUpdate = None

        self.modelDescription = None
        self.t = None

        # Adapt windowsize according to screensize:
        x_plot = None
        y_plot = None

        x_base = None
        x_dist = None
        y_base = None
        y_dist = None

        x_varDesc = None
        y_modelDesc = None
        x_rect = None
        y_rect = None

        # Run main function
        self.Main()

    def Main(self):
        import pygame
        import os
        import numpy as np

        # Custom classes
        from classes.Controls import Controls
        from classes.Models import Models
        from classes.ModelInstance import ModelInstance

        # Show plots properly
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.backends.backend_agg as agg
        import matplotlib.pyplot as plt
        import pylab

        # Initialize pygame
        pygame.init()

        # Set window size according to monitor size
        infoObject = pygame.display.Info()
        windowX = infoObject.current_w
        windowY = infoObject.current_h
        window = pygame.display.set_mode((windowX - 100, windowY - 100))

        # Initialize clock, caption, icon
        pygame.display.set_caption("Herd Immunity")  # caption of window
        clock = pygame.time.Clock()  # initialize clock that handles frame rate
        pygame.display.set_icon(pygame.image.load("data/Icon.png"))

        # Calculate positions of all surfaces according to percentages where they are in screen
        # This enables proper visualization for different screen sizes
        x_plot = int((windowX - 100) * (64 / 100))
        y_plot = int((windowY - 100) * (2.5 / 100))

        x_base = int((windowX - 100) * (20 / 100))
        x_dist = int((windowX - 100) * (12 / 100))
        y_base = int((windowY - 100) * (18 / 100))
        y_dist = int((windowY - 100) * (9 / 100))

        x_varDesc = int((windowX - 100) * (1.5 / 100))
        y_modelDesc = int((windowY - 100) * (5 / 100))
        x_rect = int((windowX - 100) * (1.5 / 100))
        y_rect = int((windowY - 100) * (2 / 100))

        # Initialize instances of custom classes
        self.controls = Controls()
        self.models = Models()

        # Initialize font
        self.font = pygame.font.Font("data/TYPEW.ttf", 20)
        self.fontBig = pygame.font.Font("data/TYPEW.ttf", 30)
        self.fontBIG = pygame.font.Font("data/TYPEW.ttf", 35)

        # Create plot once
        fig2, (ax1, ax2) = plt.subplots(2, 1, figsize=((5 / 1420) * windowX, (7 / 780) * windowY))
        self.plotUpdate = False  # only update the plot if variables were changed

        # Constant variables
        self.modelDescription = ["m0", "m1", "m2", "m3"]
        self.t = np.linspace(0, 200, 200)

        # load presets into Models-class
        self.models.loadPresetValues()

        # Show in under plot R0 or as immune people over time?
        self.plotR0 = False

        # GAME LOOP
        while self.controls.running:
            # Frame rate
            clock.tick(15)
            #print(clock.get_fps())

            # Rendering screen
            window.fill((0, 0, 0))

            # Get user inputs
            self.controls.evaluatePressedKeys()

            #################################################################################################
            """
            Print text descriptions that stay constant
            """

            # Pygame does not natively support multi-line text
            for i in range(len(self.models.variableDescription)):
                tmp = self.font.render(self.models.variableDescription[i], True, (255, 255, 255))
                # window.blit(tmp, (20, 140 + 70 * i))  # (x,y)  140=position of first line, 70=row distance
                window.blit(tmp,(x_varDesc, y_base + y_dist * i))

            # Pygame does not natively support tabs
            for i in range(len(self.modelDescription)):
                tmp = self.fontBIG.render(self.modelDescription[i], True, (255, 255, 255))
                window.blit(tmp,(x_base + x_dist * i, y_modelDesc))

            #################################################################################################
            """
            Show plot nonstop
            """


            if self.plotUpdate:
                ax1.cla()
                ax2.cla()

                # R0 is calculated differently for heterogeneous populations, so disable showing R0 then
                if self.models.variableRanges[7][self.models.modelList[0].variables[7]]!= "Homogen":
                    self.plotR0 = False
                elif self.models.variableRanges[7][self.models.modelList[1].variables[7]]!= "Homogen":
                    self.plotR0 = False
                elif self.models.variableRanges[7][self.models.modelList[2].variables[7]]!= "Homogen":
                    self.plotR0 = False
                elif self.models.variableRanges[7][self.models.modelList[2].variables[7]]!= "Homogen":
                    self.plotR0 = False
                else:
                    pass



                if self.models.modelList[0].variables[0]:
                    ax1.plot(self.t, self.models.modelList[0].I / 1000, 'b', alpha=0.5, lw=2, label='Model 0')

                    # If R0 gets shown below
                    if self.plotR0:
                        # Define variables to enhance readability
                        beta = self.models.variableRanges[1][self.models.modelList[0].variables[1]]
                        gamma = self.models.variableRanges[2][self.models.modelList[0].variables[2]]
                        lockdown = self.models.modelList[0].variables[3]
                        lockdownStart = self.models.variableRanges[4][self.models.modelList[0].variables[4]]
                        lockdownDur = self.models.variableRanges[5][self.models.modelList[0].variables[5]]
                        lockdownInt = self.models.variableRanges[6][self.models.modelList[0].variables[6]]

                        # Make lockdown-measurements into array
                        lockdownIntArray = np.ones(200)
                        if lockdown:
                            for i in range(int(lockdownStart), int(lockdownStart + lockdownDur)):
                                lockdownIntArray[i] = lockdownInt

                        # Calculate values of R over time
                        tmp = (beta / gamma) * (lockdownIntArray) * (1 - ((1000 - self.models.modelList[0].S) / 1000))

                        # Put it in plot
                        ax2.plot(self.t, tmp, 'b', alpha=0.5, lw=2, label='Model 0')

                    # If I+R is shown below
                    else:
                        ax2.plot(self.t, (1000 - self.models.modelList[0].S) / 1000, 'b', alpha=0.5, lw=2,
                                 label='Model 0')
                    # 1000-S= I+R
                if self.models.modelList[1].variables[0]:
                    ax1.plot(self.t, self.models.modelList[1].I / 1000, 'r', alpha=0.5, lw=2, label='Model 1')
                    #ax2.plot(self.t, (1000 - self.models.modelList[1].S) / 1000, 'r', alpha=0.5, lw=2, label='Model 1')
                    if self.plotR0:
                        # Define variables to enhance readability
                        beta = self.models.variableRanges[1][self.models.modelList[1].variables[1]]
                        gamma = self.models.variableRanges[2][self.models.modelList[1].variables[2]]
                        lockdown = self.models.modelList[1].variables[3]
                        lockdownStart = self.models.variableRanges[4][self.models.modelList[1].variables[4]]
                        lockdownDur = self.models.variableRanges[5][self.models.modelList[1].variables[5]]
                        lockdownInt = self.models.variableRanges[6][self.models.modelList[1].variables[6]]

                        # Make lockdown-measurements into array
                        lockdownIntArray = np.ones(200)
                        if lockdown:
                            for i in range(int(lockdownStart), int(lockdownStart + lockdownDur)):
                                lockdownIntArray[i] = lockdownInt

                        # Calculate values of R over time
                        tmp = (beta / gamma) * (lockdownIntArray) * (1 - ((1000 - self.models.modelList[1].S) / 1000))

                        # Put it in plot
                        ax2.plot(self.t, tmp, 'r', alpha=0.5, lw=2, label='Model 1')

                    # If I+R is shown below
                    else:
                        ax2.plot(self.t, (1000 - self.models.modelList[1].S) / 1000, 'r', alpha=0.5, lw=2,
                                 label='Model 1')

                if self.models.modelList[2].variables[0]:
                    ax1.plot(self.t, self.models.modelList[2].I / 1000, 'g', alpha=0.5, lw=2, label='Model 2')
                    #ax2.plot(self.t, (1000 - self.models.modelList[2].S) / 1000, 'g', alpha=0.5, lw=2, label='Model 2')
                    if self.plotR0:
                        # Define variables to enhance readability
                        beta = self.models.variableRanges[1][self.models.modelList[2].variables[1]]
                        gamma = self.models.variableRanges[2][self.models.modelList[2].variables[2]]
                        lockdown = self.models.modelList[2].variables[3]
                        lockdownStart = self.models.variableRanges[4][self.models.modelList[2].variables[4]]
                        lockdownDur = self.models.variableRanges[5][self.models.modelList[2].variables[5]]
                        lockdownInt = self.models.variableRanges[6][self.models.modelList[2].variables[6]]

                        # Make lockdown-measurements into array
                        lockdownIntArray = np.ones(200)
                        if lockdown:
                            for i in range(int(lockdownStart), int(lockdownStart + lockdownDur)):
                                lockdownIntArray[i] = lockdownInt

                        # Calculate values of R over time
                        tmp = (beta / gamma) * (lockdownIntArray) * (1 - ((1000 - self.models.modelList[2].S) / 1000))

                        # Put it in plot
                        ax2.plot(self.t, tmp, 'g', alpha=0.5, lw=2, label='Model 2')

                    # If I+R is shown below
                    else:
                        ax2.plot(self.t, (1000 - self.models.modelList[2].S) / 1000, 'g', alpha=0.5, lw=2,
                                 label='Model 2')

                if self.models.modelList[3].variables[0]:
                    ax1.plot(self.t, self.models.modelList[3].I / 1000, 'y', alpha=0.5, lw=2, label='Model 3')
                    #ax2.plot(self.t, (1000 - self.models.modelList[3].S) / 1000, 'y', alpha=0.5, lw=2, label='Model 3')
                    if self.plotR0:
                        # Define variables to enhance readability
                        beta = self.models.variableRanges[1][self.models.modelList[3].variables[1]]
                        gamma = self.models.variableRanges[2][self.models.modelList[3].variables[2]]
                        lockdown = self.models.modelList[3].variables[3]
                        lockdownStart = self.models.variableRanges[4][self.models.modelList[3].variables[4]]
                        lockdownDur = self.models.variableRanges[5][self.models.modelList[3].variables[5]]
                        lockdownInt = self.models.variableRanges[6][self.models.modelList[3].variables[6]]

                        # Make lockdown-measurements into array
                        lockdownIntArray = np.ones(200)
                        if lockdown:
                            for i in range(int(lockdownStart), int(lockdownStart + lockdownDur)):
                                lockdownIntArray[i] = lockdownInt

                        # Calculate values of R over time
                        tmp = (beta / gamma) * (lockdownIntArray) * (1 - ((1000 - self.models.modelList[3].S) / 1000))

                        # Put it in plot
                        ax2.plot(self.t, tmp, 'y', alpha=0.5, lw=2, label='Model 3')

                    # If I+R is shown below
                    else:
                        ax2.plot(self.t, (1000 - self.models.modelList[3].S) / 1000, 'y', alpha=0.5, lw=2,
                                 label='Model 3')
                self.plotUpdate = False

            # Things of plot that need to be shown every frame:

            # Upper plot (stays the same)
            ax1.set_xlabel('Time /days')
            ax1.set_ylabel('Percentage of INFECTED people')
            ax1.set_ylim(0, 0.3)
            ax1.yaxis.set_tick_params(length=0)
            ax1.xaxis.set_tick_params(length=0)
            ax1.grid(b=True, which='major', c='black', lw=0.1, ls='-')
            legend = ax1.legend()

            # Below plot
            if self.plotR0:  # Plot R-value
                ax2.set_xlabel('Time /days')
                ax2.set_ylabel('R-value over time')
                ax2.set_ylim(0, 5)
                ax2.yaxis.set_tick_params(length=0)
                ax2.xaxis.set_tick_params(length=0)
                ax2.grid(b=True, which='major', c='black', lw=0.1, ls='-')
                legend2 = ax2.legend()
            else:  # Plot immune people
                ax2.set_xlabel('Time /days')
                ax2.set_ylabel('Percentage of IMMUNE people (=I+R)')
                ax2.set_ylim(0, 1)
                ax2.yaxis.set_tick_params(length=0)
                ax2.xaxis.set_tick_params(length=0)
                ax2.grid(b=True, which='major', c='black', lw=0.1, ls='-')
                legend2 = ax2.legend()

            # Render plot to the screen
            canvas2 = agg.FigureCanvasAgg(fig2)
            canvas2.draw()
            renderer2 = canvas2.get_renderer()
            raw_data2 = renderer2.tostring_rgb()
            screen = pygame.display.get_surface()
            size2 = canvas2.get_width_height()
            surf2 = pygame.image.fromstring(raw_data2, size2, "RGB")  # .convert_alpha()
            screen.blit(surf2, (x_plot, y_plot))  # (920, 400))  # position to render the plot to

            #################################################################################################
            """
            Render ractangle that shows the current selected variable
            """

            for v in range(self.models.variableNum):
                for m in range(4):

                    if m == self.models.currentModel and v == self.models.currentVariable:
                        rectSelectColor = pygame.Rect(x_base + x_dist * m - x_rect, y_base + y_dist * v - y_rect, 140,
                                                      50)
                        rectSelectBlack = pygame.Rect(x_base + x_dist * m - x_rect + 3,
                                                      y_base + y_dist * v - y_rect + 3, 134, 44)

                        # When editing: red color, when moving:blue color
                        if self.models.modelEdit:
                            pygame.draw.rect(window, (255, 0, 0), rectSelectColor)  # red
                        else:
                            pygame.draw.rect(window, (30, 144, 255), rectSelectColor)  # blue
                        pygame.draw.rect(window, (0, 0, 0), rectSelectBlack)

            #################################################################################################
            """Render all variable values"""

            # For all variables do
            for v in range(self.models.variableNum):
                # For all models do
                for m in range(4):
                    # e.g. "showPlot"
                    if isinstance(self.models.modelList[m].variables[v], bool):
                        tmp = self.font.render(str(self.models.modelList[m].variables[v]), True, (255, 255, 255))
                        window.blit(tmp, (x_base + x_dist * m, y_base + y_dist * v))  # (x,y)

                    # If other value (e.g. "lockdownStart"), then select from range-list
                    else:
                        tmp2 = self.models.variableRanges[v][self.models.modelList[m].variables[v]]
                        tmp = self.font.render(str(tmp2), True, (255, 255, 255))
                        window.blit(tmp, (x_base + x_dist * m, y_base + y_dist * v))

            #################################################################################################
            """Render R0-value"""

            # For all models, check if plot is shown
            for m in range(4):
                if self.models.modelList[m].variables[0]:
                    # Avoid dividing by zero
                    if self.models.modelList[m].variables[2] != 0:
                        beta = self.models.variableRanges[1][self.models.modelList[m].variables[1]]
                        gamma = self.models.variableRanges[2][self.models.modelList[m].variables[2]]

                        tmp = self.font.render("R0: " + str(round(beta / gamma, 1)), True, (0, 255, 255))
                        window.blit(tmp, (x_base + x_dist * m, y_base + y_dist * self.models.variableNum - y_dist / 3))
                    else:
                        tmp = self.font.render("R0: inf", True, (0, 255, 255))
                        window.blit(tmp, (x_base + x_dist * m, y_base + y_dist * self.models.variableNum - y_dist / 3))

            #################################################################################################
            """GET KEY INPUTS"""

            # Do we edit or navigate?
            if self.controls.keyPressedX:
                self.models.modelEdit = not self.models.modelEdit  # change it to other value respectively
                self.controls.keyPressedX = False

            # Select which plot is shown below
            if self.controls.keyPressedR:
                self.plotR0 = not self.plotR0
                self.controls.keyPressedR = False
                self.plotUpdate = True

            # Setting preset-values depending on which key was pressed
            if self.controls.keyPressedQ:
                self.models.setPreset("test3")
                self.models.modelList[
                    self.models.currentModel].updateSIRvalues()  # update number of sus/infected/recovered for new variables
                self.plotUpdate = True
            if self.controls.keyPressedE:
                self.models.setPreset("ebola")
                self.models.modelList[
                    self.models.currentModel].updateSIRvalues()
                self.plotUpdate = True
            if self.controls.keyPressedC:
                self.models.setPreset("covid")
                self.models.modelList[
                    self.models.currentModel].updateSIRvalues()
                self.plotUpdate = True
            if self.controls.keyPressedM:
                self.models.setPreset("measles")
                self.models.modelList[
                    self.models.currentModel].updateSIRvalues()
                self.plotUpdate = True
            if self.controls.keyPressedP:
                self.models.setPreset("polio")
                self.models.modelList[
                    self.models.currentModel].updateSIRvalues()
                self.plotUpdate = True

            #################################################################################################
            """When editing, interpret commands different than when navigating through variables"""

            # Edit variables
            if self.models.modelEdit:

                # Abbreviating for readability
                m = self.models.currentModel
                v = self.models.currentVariable

                if self.controls.keyPressedRight:
                    self.controls.keyPressedRight = False
                    if isinstance(self.models.modelList[m].variables[v], bool):  # Edit a boolean
                        self.models.modelList[m].variables[v] = not self.models.modelList[m].variables[v]
                    else:  # Edit everything else (=range-list)
                        # If we havent reached last entry of range yet
                        if self.models.modelList[m].variables[v] < len(self.models.variableRanges[v]) - 1:
                            self.models.modelList[m].variables[v] += 1

                    self.models.modelList[m].updateSIRvalues()  # update number of S/I/R for new variables
                    self.plotUpdate = True

                if self.controls.keyPressedLeft:
                    self.controls.keyPressedLeft = False
                    if isinstance(self.models.modelList[m].variables[v], bool):
                        self.models.modelList[m].variables[v] = not self.models.modelList[m].variables[v]
                    else:
                        if self.models.modelList[m].variables[v] > 0:
                            self.models.modelList[m].variables[v] -= 1
                    self.models.modelList[
                        m].updateSIRvalues()
                    self.plotUpdate = True


            # Navigating through variables:
            else:
                if self.controls.keyPressedRight:
                    if self.models.currentModel < 4 - 1:
                        self.models.currentModel += 1
                        self.controls.keyPressedRight = False
                    # else: stay at model=4

                if self.controls.keyPressedLeft:
                    if self.models.currentModel > 0:
                        self.models.currentModel -= 1
                        self.controls.keyPressedLeft = False
                    # else: stay at model=0

                if self.controls.keyPressedUp:
                    if self.models.currentVariable > 0:
                        self.models.currentVariable -= 1
                        self.controls.keyPressedUp = False
                    # else: stay at 1st variable

                if self.controls.keyPressedDown:
                    if self.models.currentVariable < self.models.variableNum - 1:
                        self.models.currentVariable += 1
                        self.controls.keyPressedDown = False
                    # else: stay at last variable

            #################################################################################################
            """UPDATE THE SCREEN"""

            pygame.display.flip()  # After drawing everything, flip the display


# Running the code
MainRun()
